document.addEventListener("DOMContentLoaded", function(){
    let navList = document.querySelector(".nav__list");
    let header = document.querySelector(".index-page__header");
    let burgerMenu = document.querySelector(".burger");
    let navLink = document.querySelectorAll(".nav__link");
    let section = document.querySelectorAll("section");
    let slogan = document.querySelector(".slogan__title");
    let title = document.querySelector(".sitename__title");
    let heroParallax = document.querySelector(".hero__parallax");
    let parallaxStyle = getComputedStyle(heroParallax);
    let styleBg = parallaxStyle.backgroundPosition;
    
    var scrollHeight = Math.max(
        document.body.scrollHeight, document.documentElement.scrollHeight,
        document.body.offsetHeight, document.documentElement.offsetHeight,
        document.body.clientHeight, document.documentElement.clientHeight
      );
      for (let i = 0; i < navLink.length; i++) {
            navLink[i].setAttribute("href", navLink[i].getAttribute("href").slice(1));
      }
      
      function getCoords(el) {
        var box = el.getBoundingClientRect();
      
        return {
          top: box.top + pageYOffset,
          left: box.left + pageXOffset
        };
      
      };

      function parallax(el) {
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        let arr = styleBg.split(" ");
        el.style.backgroundPosition = arr[0] + " " + (parseInt(arr[1]) + scrollTop/15) + "px";
      }

      setTimeout(function(){
        slogan.classList.add("animated");
        title.classList.toggle("bounceInDown");
      }, 1000);

      title.classList.add("animated");
      setInterval(function(){
        
        slogan.classList.toggle("swing");
      }, 2000);
      
    burgerMenu.addEventListener("click", function(e){
        e.preventDefault();
        burgerMenu.classList.toggle("burger-close");
    })
    document.addEventListener("click", function(e) {
        if(burgerMenu.classList.contains("burger-close") && e.target.classList.contains("burger") != true){
            burgerMenu.classList.remove("burger-close");
        }
            
    })

    window.addEventListener("scroll", function(){
        let docWidth = document.documentElement.clientWidth;
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        if(scrollTop > header.offsetHeight && docWidth < 1024) {
            header.classList.add("sticky");
            if(docWidth <= 768){
                navList.style.position = "fixed";
            }else {
                navList.style.position = "";
            }
            
        }else{
            header.classList.remove("sticky");
            navList.style.position = "";
        }
        checkSection();
        highlight();
        parallax(heroParallax);
       
    })
    

    function highlight() {
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        for (let i = 0; i < navLink.length; i++) {
            if(navLink[i].parentElement.classList.contains("highlight")) {
                navLink[i].parentElement.classList.remove("highlight");
            }
            if(checkSection().getAttribute("id") != null && checkSection().getAttribute("id") == navLink[i].getAttribute("href")){
                navLink[i].parentElement.classList.add("highlight");
            }
            if(scrollTop == (scrollHeight - document.documentElement.clientHeight)){
                navLink[i].parentElement.classList.remove("highlight");
                navLink[navLink.length - 1].parentElement.classList.add("highlight");
            }else {
                navLink[navLink.length - 1].parentElement.classList.remove("highlight");
            }
            
        }
        }
    
    
    function checkSection() {
        var centerX = document.documentElement.clientWidth / 2;
        var centerY = document.documentElement.clientHeight / 2;
        var elem = document.elementFromPoint(centerX, centerY);
        var el = elem;
        while(el.tagName != "SECTION") {
            el = el.parentElement;
        }
        
        return el;
    }

    
    navList.addEventListener("click", function(event) {
        
        if(event.target.nodeName != "A") return;
        event.preventDefault();
            for (let i = 0; i < section.length; i++) {
                if(section[i].getAttribute("id") == event.target.getAttribute("href")) {
                    if(document.documentElement.clientWidth < 1024){
                        window.scrollTo(0, getCoords(section[i]).top - header.offsetHeight);
                    }else{
                        window.scrollTo(0, getCoords(section[i]).top);
                    }
                    
                  
                }
                    
                    
            }       
    });



});
